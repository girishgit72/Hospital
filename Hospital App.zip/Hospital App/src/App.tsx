/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, FormEvent } from 'react';
import {
  Activity,
  Calendar,
  Users,
  ShieldAlert,
  FileCode,
  CheckCircle,
  Clock,
  Trash2,
  Edit2,
  Plus,
  Search,
  Filter,
  ShieldCheck,
  Heart,
  UserPlus,
  Database,
  AlertTriangle,
  RefreshCw,
  X,
  ChevronRight,
  User,
  Stethoscope,
  MapPin,
  FileText,
  Info
} from 'lucide-react';
import { Patient, Appointment, Doctor, DbDiagnostics } from './types';

export default function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState<'dashboard' | 'patients' | 'schedule' | 'diagnostics' | 'staff'>('dashboard');

  // Core clinical states
  const [patients, setPatients] = useState<Patient[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [diagnostics, setDiagnostics] = useState<DbDiagnostics | null>(null);

  // App UI states
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [genderFilter, setGenderFilter] = useState<string>('All');
  const [bloodFilter, setBloodFilter] = useState<string>('All');
  const [doctorFilter, setDoctorFilter] = useState<string>('All');

  // Patient Modal / Side-panel states
  const [isPatientModalOpen, setIsPatientModalOpen] = useState(false);
  const [patientFormMode, setPatientFormMode] = useState<'add' | 'edit'>('add');
  const [selectedPatientId, setSelectedPatientId] = useState<string | null>(null);
  const [patientForm, setPatientForm] = useState({
    name: '',
    dob: '',
    gender: 'Male' as Patient['gender'],
    bloodType: 'O+' as Patient['bloodType'],
    contact: '',
    allergies: '',
    medicalHistory: ''
  });

  // Appointment Modal / Side-panel states
  const [isApptModalOpen, setIsApptModalOpen] = useState(false);
  const [apptFormMode, setApptFormMode] = useState<'add' | 'edit'>('add');
  const [selectedApptId, setSelectedApptId] = useState<string | null>(null);
  const [apptForm, setApptForm] = useState({
    patientId: '',
    doctorName: '',
    date: new Date().toISOString().split('T')[0],
    time: '09:00',
    duration: 30,
    status: 'Scheduled' as Appointment['status'],
    notes: ''
  });

  // Detailed view models
  const [viewingPatient, setViewingPatient] = useState<Patient | null>(null);
  const [viewingAppt, setViewingAppt] = useState<Appointment | null>(null);

  // Auto-clear notifications
  useEffect(() => {
    if (successMsg) {
      const timer = setTimeout(() => setSuccessMsg(null), 5000);
      return () => clearTimeout(timer);
    }
  }, [successMsg]);

  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => setError(null), 8000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  // Initial load
  useEffect(() => {
    fetchInitialData();
  }, []);

  const fetchInitialData = async () => {
    setLoading(true);
    try {
      const [resPatients, resAppts, resDoctors, resDiag] = await Promise.all([
        fetch('/api/patients'),
        fetch('/api/appointments'),
        fetch('/api/doctors'),
        fetch('/api/diagnostics')
      ]);

      if (!resPatients.ok || !resAppts.ok || !resDoctors.ok || !resDiag.ok) {
        throw new Error('Failed to retrieve fresh clinical records from server.');
      }

      const patientsData = await resPatients.json();
      const appointmentsData = await resAppts.json();
      const doctorsData = await resDoctors.json();
      const diagnosticsData = await resDiag.json();

      setPatients(patientsData);
      setAppointments(appointmentsData);
      setDoctors(doctorsData);
      setDiagnostics(diagnosticsData);
    } catch (err: any) {
      console.error('Error fetching clinic data:', err);
      setError(err.message || 'Server connection error. Please make sure the backend is active.');
    } finally {
      setLoading(false);
    }
  };

  const refreshDiagnosticsOnly = async () => {
    try {
      const res = await fetch('/api/diagnostics');
      if (res.ok) {
        const data = await res.json();
        setDiagnostics(data);
      }
    } catch (err) {
      console.error('Error updating diagnostics:', err);
    }
  };

  // --- CRUD OPERATIONS ---

  // Patients
  const handleSavePatient = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientForm.name || !patientForm.dob || !patientForm.contact) {
      setError('Please fill out Name, Date of Birth, and Contact numbers.');
      return;
    }

    try {
      const url = patientFormMode === 'add' ? '/api/patients' : `/api/patients/${selectedPatientId}`;
      const method = patientFormMode === 'add' ? 'POST' : 'PUT';

      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(patientForm)
      });

      if (!response.ok) {
        const errBody = await response.json();
        throw new Error(errBody.error || 'Failed to preserve patient records.');
      }

      const savedPatient = await response.json();

      if (patientFormMode === 'add') {
        setPatients(prev => [...prev, savedPatient]);
        setSuccessMsg(`Patient record successfully created: ${savedPatient.id}`);
      } else {
        setPatients(prev => prev.map(p => p.id === savedPatient.id ? savedPatient : p));
        setSuccessMsg(`Patient records successfully updated: ${savedPatient.id}`);
        // If we are currently viewing this patient, update details
        if (viewingPatient?.id === savedPatient.id) {
          setViewingPatient(savedPatient);
        }
      }

      // Re-fetch appointments because name might have changed cascadingly
      const apptRes = await fetch('/api/appointments');
      if (apptRes.ok) {
        setAppointments(await apptRes.json());
      }

      setIsPatientModalOpen(false);
      resetPatientForm();
      refreshDiagnosticsOnly();
    } catch (err: any) {
      setError(err.message || 'An error occurred while saving patient records.');
    }
  };

  const handleDeletePatient = async (id: string) => {
    if (!confirm('Warning: Deleting this patient will permanently wipe all their historical records and cancel all scheduled appointments. Do you wish to proceed?')) {
      return;
    }

    try {
      const response = await fetch(`/api/patients/${id}`, { method: 'DELETE' });
      if (!response.ok) {
        throw new Error('Failed to destroy patient record.');
      }

      setPatients(prev => prev.filter(p => p.id !== id));
      setAppointments(prev => prev.filter(a => a.patientId !== id));
      setSuccessMsg(`Patient record ${id} and their appointment schedule have been cleanly destroyed.`);
      if (viewingPatient?.id === id) {
        setViewingPatient(null);
      }
      refreshDiagnosticsOnly();
    } catch (err: any) {
      setError(err.message || 'An error occurred during deletion.');
    }
  };

  const openAddPatient = () => {
    setPatientFormMode('add');
    resetPatientForm();
    setIsPatientModalOpen(true);
  };

  const openEditPatient = (p: Patient) => {
    setPatientFormMode('edit');
    setSelectedPatientId(p.id);
    setPatientForm({
      name: p.name,
      dob: p.dob,
      gender: p.gender,
      bloodType: p.bloodType,
      contact: p.contact,
      allergies: p.allergies,
      medicalHistory: p.medicalHistory
    });
    setIsPatientModalOpen(true);
  };

  const resetPatientForm = () => {
    setPatientForm({
      name: '',
      dob: '',
      gender: 'Male',
      bloodType: 'O+',
      contact: '',
      allergies: '',
      medicalHistory: ''
    });
    setSelectedPatientId(null);
  };

  // Appointments
  const handleSaveAppointment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!apptForm.patientId || !apptForm.doctorName || !apptForm.date || !apptForm.time || !apptForm.duration) {
      setError('Please assign a patient, professional, date, and appointment slot.');
      return;
    }

    // Get doctor specialty from database configuration
    const doc = doctors.find(d => d.name === apptForm.doctorName);
    const specialty = doc ? doc.specialty : 'Clinical Medicine';

    // Get patient name
    const pat = patients.find(p => p.id === apptForm.patientId);
    const patientName = pat ? pat.name : 'Unknown Patient';

    const fullApptData = {
      ...apptForm,
      patientName,
      specialty
    };

    try {
      const url = apptFormMode === 'add' ? '/api/appointments' : `/api/appointments/${selectedApptId}`;
      const method = apptFormMode === 'add' ? 'POST' : 'PUT';

      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(fullApptData)
      });

      if (!response.ok) {
        const errBody = await response.json();
        throw new Error(errBody.message || errBody.error || 'Failed to record clinic appointment.');
      }

      const savedAppt = await response.json();

      if (apptFormMode === 'add') {
        setAppointments(prev => [...prev, savedAppt]);
        setSuccessMsg(`Appointment booked successfully: ${savedAppt.id}`);
      } else {
        setAppointments(prev => prev.map(a => a.id === savedAppt.id ? savedAppt : a));
        setSuccessMsg(`Appointment scheduled slot updated: ${savedAppt.id}`);
        if (viewingAppt?.id === savedAppt.id) {
          setViewingAppt(savedAppt);
        }
      }

      setIsApptModalOpen(false);
      resetApptForm();
      refreshDiagnosticsOnly();
    } catch (err: any) {
      setError(err.message || 'An error occurred during scheduling reservation.');
    }
  };

  const handleDeleteAppointment = async (id: string) => {
    if (!confirm('Are you sure you want to permanently delete this appointment from the clinic queue?')) {
      return;
    }

    try {
      const response = await fetch(`/api/appointments/${id}`, { method: 'DELETE' });
      if (!response.ok) {
        throw new Error('Failed to cancel appointment database record.');
      }

      setAppointments(prev => prev.filter(a => a.id !== id));
      setSuccessMsg(`Appointment ${id} has been permanently deleted.`);
      if (viewingAppt?.id === id) {
        setViewingAppt(null);
      }
      refreshDiagnosticsOnly();
    } catch (err: any) {
      setError(err.message || 'An error occurred during appointment deletion.');
    }
  };

  const openBookAppt = (preselectedPatientId?: string) => {
    setApptFormMode('add');
    resetApptForm();
    if (preselectedPatientId) {
      setApptForm(prev => ({ ...prev, patientId: preselectedPatientId }));
    } else if (patients.length > 0) {
      setApptForm(prev => ({ ...prev, patientId: patients[0].id }));
    }

    if (doctors.length > 0) {
      setApptForm(prev => ({ ...prev, doctorName: doctors[0].name }));
    }

    setIsApptModalOpen(true);
  };

  const openEditAppt = (a: Appointment) => {
    setApptFormMode('edit');
    setSelectedApptId(a.id);
    setApptForm({
      patientId: a.patientId,
      doctorName: a.doctorName,
      date: a.date,
      time: a.time,
      duration: a.duration,
      status: a.status,
      notes: a.notes
    });
    setIsApptModalOpen(true);
  };

  const resetApptForm = () => {
    setApptForm({
      patientId: patients[0]?.id || '',
      doctorName: doctors[0]?.name || '',
      date: new Date().toISOString().split('T')[0],
      time: '09:00',
      duration: 30,
      status: 'Scheduled',
      notes: ''
    });
    setSelectedApptId(null);
  };

  // Helper: Live Client Conflict Checker
  const clientConflict = (() => {
    if (!isApptModalOpen || !apptForm.doctorName || !apptForm.date || !apptForm.time || !apptForm.duration) {
      return null;
    }

    // Helper to convert HH:MM to minutes-from-midnight
    const timeToMinutes = (t: string): number => {
      const parts = t.split(':');
      if (parts.length !== 2) return 0;
      return parseInt(parts[0], 10) * 60 + parseInt(parts[1], 10);
    };

    const isOverlapping = (t1: string, d1: number, t2: string, d2: number): boolean => {
      const s1 = timeToMinutes(t1);
      const e1 = s1 + d1;
      const s2 = timeToMinutes(t2);
      const e2 = s2 + d2;
      return s1 < e2 && s2 < e1;
    };

    const conflict = appointments.find(appt => {
      return (
        appt.id !== selectedApptId &&
        appt.status !== 'Cancelled' &&
        appt.doctorName.toLowerCase() === apptForm.doctorName.toLowerCase() &&
        appt.date === apptForm.date &&
        isOverlapping(appt.time, appt.duration, apptForm.time, apptForm.duration)
      );
    });

    return conflict || null;
  })();

  // Filter systems
  const filteredPatients = patients.filter(p => {
    const query = searchQuery.toLowerCase();
    const matchesSearch =
      p.id.toLowerCase().includes(query) ||
      p.name.toLowerCase().includes(query) ||
      p.bloodType.toLowerCase().includes(query) ||
      p.allergies.toLowerCase().includes(query) ||
      p.medicalHistory.toLowerCase().includes(query) ||
      p.contact.includes(query);

    const matchesGender = genderFilter === 'All' || p.gender === genderFilter;
    const matchesBlood = bloodFilter === 'All' || p.bloodType === bloodFilter;

    return matchesSearch && matchesGender && matchesBlood;
  });

  const filteredAppointments = appointments.filter(a => {
    const query = searchQuery.toLowerCase();
    const matchesSearch =
      a.id.toLowerCase().includes(query) ||
      a.patientName.toLowerCase().includes(query) ||
      a.patientId.toLowerCase().includes(query) ||
      a.doctorName.toLowerCase().includes(query) ||
      a.notes.toLowerCase().includes(query) ||
      a.specialty.toLowerCase().includes(query);

    const matchesDoctor = doctorFilter === 'All' || a.doctorName === doctorFilter;

    return matchesSearch && matchesDoctor;
  });

  // Calculate day of week to highlight scheduled shifts
  const getSimulatedDayName = () => {
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return days[new Date().getDay()];
  };

  // Diagnostics & Statistics counts
  const stats = {
    totalPatients: patients.length,
    activeAppointments: appointments.filter(a => a.status === 'Scheduled').length,
    completedAppointments: appointments.filter(a => a.status === 'Completed').length,
    conflictsCount: (() => {
      // Find count of overlaps
      let count = 0;
      const active = appointments.filter(a => a.status !== 'Cancelled');
      for (let i = 0; i < active.length; i++) {
        for (let j = i + 1; j < active.length; j++) {
          const a1 = active[i];
          const a2 = active[j];
          if (
            a1.doctorName.toLowerCase() === a2.doctorName.toLowerCase() &&
            a1.date === a2.date
          ) {
            // Check overlap
            const parseMin = (t: string) => {
              const p = t.split(':');
              return parseInt(p[0], 10) * 60 + parseInt(p[1], 10);
            };
            const s1 = parseMin(a1.time);
            const e1 = s1 + a1.duration;
            const s2 = parseMin(a2.time);
            const e2 = s2 + a2.duration;
            if (s1 < e2 && s2 < e1) {
              count++;
            }
          }
        }
      }
      return count;
    })()
  };

  // Weekly workflow efficiency stats simulation
  const appointmentsPerDay = (() => {
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    const counts = [0, 0, 0, 0, 0];
    
    // Distribute appointments
    appointments.forEach(a => {
      // map date to day of week
      const dayIndex = new Date(a.date).getDay(); // 0 is Sun, 1 is Mon
      if (dayIndex >= 1 && dayIndex <= 5) {
        counts[dayIndex - 1]++;
      }
    });

    const max = Math.max(...counts, 1);
    return days.map((day, i) => ({
      day,
      count: counts[i],
      percentage: Math.min(100, Math.max(15, (counts[i] / max) * 100))
    }));
  })();

  return (
    <div className="glass-bg min-h-screen text-slate-800 flex flex-col font-sans transition-all duration-300">
      
      {/* GLOBAL SYSTEM ALERTS */}
      {error && (
        <div id="system-error-toast" className="fixed top-4 right-4 z-50 max-w-md p-4 bg-rose-50/90 backdrop-blur-md border border-rose-200 shadow-lg rounded-xl flex items-start gap-3 animate-bounce">
          <AlertTriangle className="text-rose-600 flex-shrink-0 mt-0.5" size={18} />
          <div className="flex-1">
            <h4 className="text-sm font-semibold text-rose-800">Clinical Data Alert</h4>
            <p className="text-xs text-rose-700 mt-1">{error}</p>
          </div>
          <button onClick={() => setError(null)} className="text-rose-400 hover:text-rose-600">
            <X size={16} />
          </button>
        </div>
      )}

      {successMsg && (
        <div id="system-success-toast" className="fixed top-4 right-4 z-50 max-w-md p-4 bg-emerald-50/90 backdrop-blur-md border border-emerald-200 shadow-lg rounded-xl flex items-start gap-3 animate-fade-in">
          <ShieldCheck className="text-emerald-600 flex-shrink-0 mt-0.5" size={18} />
          <div className="flex-1">
            <h4 className="text-sm font-semibold text-emerald-800">Integrity Verified</h4>
            <p className="text-xs text-emerald-700 mt-1">{successMsg}</p>
          </div>
          <button onClick={() => setSuccessMsg(null)} className="text-emerald-400 hover:text-emerald-600">
            <X size={16} />
          </button>
        </div>
      )}

      {/* OUTER CLINICAL WRAPPER */}
      <div className="flex flex-1 h-screen overflow-hidden">
        
        {/* SIDEBAR NAVIGATION - Frosted Glass panel */}
        <aside id="vitaflow-sidebar" className="sidebar glass-panel w-64 flex flex-col flex-shrink-0 border-l-0 rounded-r-3xl m-3 mr-0 shadow-lg relative overflow-hidden">
          {/* Decorative backdrop blobs just for aesthetics inside sidebar */}
          <div className="absolute -top-12 -left-12 w-24 h-24 rounded-full bg-sky-200/40 blur-xl"></div>
          <div className="absolute bottom-4 -right-8 w-20 h-20 rounded-full bg-emerald-100/40 blur-xl"></div>

          <div className="relative z-10 p-6 pb-2">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-sky-500/10 rounded-xl border border-sky-400/20 text-sky-600">
                <Activity size={24} className="animate-pulse" />
              </div>
              <div>
                <h1 className="text-xl font-extrabold tracking-tight text-sky-800">VITAFLOW</h1>
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block">Clinical OS v2.4</span>
              </div>
            </div>
            
            <div className="mt-4 p-2.5 bg-slate-50/50 rounded-xl border border-white/40 text-center text-[10px] font-semibold text-slate-600">
              Binary Vault Storage Mode
            </div>
          </div>

          {/* Nav Items */}
          <nav className="relative z-10 flex-1 px-4 py-6 space-y-1.5 overflow-y-auto">
            <button
              id="nav-dashboard"
              onClick={() => { setActiveTab('dashboard'); resetPatientForm(); resetApptForm(); }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all duration-200 ${
                activeTab === 'dashboard'
                  ? 'bg-sky-600 text-white shadow-md shadow-sky-600/10'
                  : 'text-slate-600 hover:bg-white/40 hover:text-slate-900'
              }`}
            >
              <Activity size={18} />
              <span>Dashboard Workspace</span>
            </button>

            <button
              id="nav-patients"
              onClick={() => { setActiveTab('patients'); resetPatientForm(); }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all duration-200 ${
                activeTab === 'patients'
                  ? 'bg-sky-600 text-white shadow-md shadow-sky-600/10'
                  : 'text-slate-600 hover:bg-white/40 hover:text-slate-900'
              }`}
            >
              <Users size={18} />
              <span>Patient Records</span>
              <span className="ml-auto text-[10px] px-2 py-0.5 bg-sky-100 text-sky-800 rounded-full font-bold">
                {patients.length}
              </span>
            </button>

            <button
              id="nav-schedule"
              onClick={() => { setActiveTab('schedule'); resetApptForm(); }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all duration-200 ${
                activeTab === 'schedule'
                  ? 'bg-sky-600 text-white shadow-md shadow-sky-600/10'
                  : 'text-slate-600 hover:bg-white/40 hover:text-slate-900'
              }`}
            >
              <Calendar size={18} />
              <span>Doctor Schedule</span>
              {stats.conflictsCount > 0 && (
                <span className="ml-auto flex h-2 w-2 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
                </span>
              )}
            </button>

            <button
              id="nav-diagnostics"
              onClick={() => { setActiveTab('diagnostics'); refreshDiagnosticsOnly(); }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all duration-200 ${
                activeTab === 'diagnostics'
                  ? 'bg-sky-600 text-white shadow-md shadow-sky-600/10'
                  : 'text-slate-600 hover:bg-white/40 hover:text-slate-900'
              }`}
            >
              <FileCode size={18} />
              <span>Database Vault</span>
              <span className="ml-auto text-[9px] px-1.5 py-0.5 bg-emerald-100 text-emerald-800 rounded font-mono font-bold">
                .DAT
              </span>
            </button>

            <button
              id="nav-staff"
              onClick={() => setActiveTab('staff')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all duration-200 ${
                activeTab === 'staff'
                  ? 'bg-sky-600 text-white shadow-md shadow-sky-600/10'
                  : 'text-slate-600 hover:bg-white/40 hover:text-slate-900'
              }`}
            >
              <Stethoscope size={18} />
              <span>Medical Officers</span>
            </button>
          </nav>

          {/* Quick-stats widget footer in sidebar */}
          <div className="relative z-10 p-4 border-t border-slate-200/50 bg-white/20">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Storage Integrity</span>
              <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-600">
                <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping"></div>
                SECURE
              </span>
            </div>
            <div className="text-[11px] font-mono text-slate-600 bg-white/40 p-2 rounded-lg border border-white/60 overflow-hidden text-ellipsis whitespace-nowrap">
              File: patients.dat
            </div>
          </div>
        </aside>

        {/* MAIN DISPLAY AREA */}
        <main className="flex-1 flex flex-col overflow-hidden p-3 min-w-0">
          
          {/* TOP CLINICAL APP BAR */}
          <header id="clinical-top-bar" className="h-20 flex items-center justify-between px-6 mb-3 flex-shrink-0">
            <div className="flex items-center gap-4">
              <h2 className="text-xl font-bold text-slate-800">
                {activeTab === 'dashboard' && 'Clinical Command Center'}
                {activeTab === 'patients' && 'Electronic Health Records'}
                {activeTab === 'schedule' && 'Physician Allocator & Bookings'}
                {activeTab === 'diagnostics' && 'Binary File Diagnostics'}
                {activeTab === 'staff' && 'Active Specialists Registry'}
              </h2>
              {loading && (
                <div className="flex items-center gap-1.5 text-xs text-sky-600 font-semibold bg-sky-50 px-2.5 py-1 rounded-full animate-pulse border border-sky-200">
                  <RefreshCw size={12} className="animate-spin" />
                  Synchronizing Database...
                </div>
              )}
            </div>

            {/* Global Search box in Top bar */}
            <div className="flex items-center gap-4">
              {(activeTab === 'patients' || activeTab === 'schedule') && (
                <div className="relative">
                  <Search className="absolute left-3.5 top-2.5 text-slate-400" size={16} />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={activeTab === 'patients' ? "Search by ID, name, contact..." : "Search appointments..."}
                    className="search-box glass-input pl-10 pr-4 py-2 text-sm w-72 rounded-xl focus:shadow-sm"
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery('')}
                      className="absolute right-3 top-3 text-slate-400 hover:text-slate-600"
                    >
                      <X size={14} />
                    </button>
                  )}
                </div>
              )}

              {/* Doctor Avatar Badge */}
              <div className="flex items-center gap-3 bg-white/45 backdrop-blur-md p-1.5 pr-4 rounded-full border border-white/60 shadow-sm">
                <div className="avatar w-9 h-9 rounded-full bg-sky-600 text-white font-bold flex items-center justify-center text-sm shadow-sm">
                  MD
                </div>
                <div>
                  <div className="font-semibold text-xs text-slate-800 leading-none">Clinical Admin</div>
                  <div className="text-[9px] text-slate-500 font-semibold mt-1">St. Jude Medical</div>
                </div>
              </div>
            </div>
          </header>

          {/* INNER VIEWPORTS CONTAINER */}
          <div className="flex-1 overflow-y-auto px-6 pb-6 min-h-0">

            {/* ERROR PLACEHOLDER */}
            {patients.length === 0 && !loading && (
              <div className="p-8 mb-6 glass-panel rounded-2xl border-amber-200 bg-amber-50/20 text-center max-w-xl mx-auto">
                <AlertTriangle className="text-amber-600 mx-auto mb-3" size={32} />
                <h3 className="text-base font-bold text-amber-800">No Patient Records Detected</h3>
                <p className="text-xs text-slate-600 mt-2">
                  The local database `.dat` files may be uninitialized or empty. VitaFlow has created default diagnostic clinical seeds. Click below to synchronize and restore standard active data.
                </p>
                <button
                  onClick={fetchInitialData}
                  className="mt-4 px-4 py-2 bg-sky-600 text-white rounded-lg text-xs font-bold hover:bg-sky-700 transition"
                >
                  Force Initial Sync
                </button>
              </div>
            )}

            {/* --- VIEW: DASHBOARD --- */}
            {activeTab === 'dashboard' && (
              <div id="dashboard-viewport" className="space-y-6">
                
                {/* Real-time Conflict Alert Banner */}
                {stats.conflictsCount > 0 && (
                  <div id="dashboard-conflict-banner" className="p-4 bg-rose-50/80 backdrop-blur-md border-l-4 border-rose-500 border border-rose-200/50 rounded-r-xl flex items-start gap-3.5 shadow-sm">
                    <ShieldAlert className="text-rose-600 flex-shrink-0 mt-0.5 animate-pulse" size={20} />
                    <div className="flex-1">
                      <h3 className="text-sm font-bold text-rose-900">
                        Physician Scheduling Conflict Alert ({stats.conflictsCount})
                      </h3>
                      <p className="text-xs text-rose-700 mt-1">
                        We detected overlapping consultation time blocks allocated to the same doctor on the same clinical day. This creates resource bottlenecks in clinical operations.
                      </p>
                    </div>
                    <button
                      onClick={() => setActiveTab('schedule')}
                      className="px-3.5 py-1.5 bg-rose-600 text-white hover:bg-rose-700 transition text-[11px] font-bold rounded-lg flex items-center gap-1"
                    >
                      <span>Resolve Conflicts</span>
                      <ChevronRight size={12} />
                    </button>
                  </div>
                )}

                {/* KPI Cards Grid */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  
                  {/* Total Patients */}
                  <div className="card glass-panel p-5 rounded-2xl relative overflow-hidden flex flex-col justify-between h-32 hover:translate-y-[-2px] transition-transform">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Total Patients</span>
                        <h4 className="text-3xl font-extrabold text-slate-800 mt-1">{stats.totalPatients}</h4>
                      </div>
                      <div className="p-2.5 bg-sky-500/10 text-sky-600 rounded-xl">
                        <Users size={18} />
                      </div>
                    </div>
                    <div className="text-[10px] text-slate-500 flex items-center gap-1.5">
                      <span className="text-emerald-600 font-bold">↑ Active</span>
                      <span>Health Record Database Vault</span>
                    </div>
                  </div>

                  {/* Scheduled Appointments */}
                  <div className="card glass-panel p-5 rounded-2xl relative overflow-hidden flex flex-col justify-between h-32 hover:translate-y-[-2px] transition-transform">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Queue Load</span>
                        <h4 className="text-3xl font-extrabold text-slate-800 mt-1">{stats.activeAppointments}</h4>
                      </div>
                      <div className="p-2.5 bg-indigo-500/10 text-indigo-600 rounded-xl">
                        <Clock size={18} />
                      </div>
                    </div>
                    <div className="text-[10px] text-slate-500 flex items-center gap-1.5">
                      <span className="text-indigo-600 font-bold">Upcoming</span>
                      <span>Physician consultations today</span>
                    </div>
                  </div>

                  {/* Conflict Tracker */}
                  <div className={`card glass-panel p-5 rounded-2xl relative overflow-hidden flex flex-col justify-between h-32 hover:translate-y-[-2px] transition-transform border ${stats.conflictsCount > 0 ? 'border-rose-200 bg-rose-50/10' : ''}`}>
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Conflict Load</span>
                        <h4 className={`text-3xl font-extrabold mt-1 ${stats.conflictsCount > 0 ? 'text-rose-600' : 'text-slate-800'}`}>
                          {stats.conflictsCount}
                        </h4>
                      </div>
                      <div className={`p-2.5 rounded-xl ${stats.conflictsCount > 0 ? 'bg-rose-500/15 text-rose-600 animate-pulse' : 'bg-emerald-500/10 text-emerald-600'}`}>
                        {stats.conflictsCount > 0 ? <ShieldAlert size={18} /> : <ShieldCheck size={18} />}
                      </div>
                    </div>
                    <div className="text-[10px] text-slate-500">
                      {stats.conflictsCount > 0 ? (
                        <span className="text-rose-600 font-bold">Action Required: Overlaps</span>
                      ) : (
                        <span className="text-emerald-600 font-bold">Perfect Schedule Alignment</span>
                      )}
                    </div>
                  </div>

                  {/* Dat Store Status */}
                  <div className="card glass-panel p-5 rounded-2xl relative overflow-hidden flex flex-col justify-between h-32 hover:translate-y-[-2px] transition-transform">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Binary Storage</span>
                        <h4 className="text-sm font-mono font-bold text-slate-800 mt-2.5 truncate">
                          {diagnostics?.patientsFile.size ? `${(diagnostics.patientsFile.size + (diagnostics.appointmentsFile?.size || 0))} Bytes` : 'Reading...'}
                        </h4>
                      </div>
                      <div className="p-2.5 bg-emerald-500/10 text-emerald-600 rounded-xl">
                        <Database size={18} />
                      </div>
                    </div>
                    <div className="text-[10px] text-slate-500 flex items-center justify-between">
                      <span className="text-emerald-600 font-bold">XOR Obfuscated</span>
                      <span className="font-mono text-[9px]">patients.dat</span>
                    </div>
                  </div>
                </div>

                {/* Dashboard Main Grid Layout */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  
                  {/* LEFT: Live Schedule Stream */}
                  <div className="lg:col-span-7 glass-panel p-6 rounded-2xl flex flex-col min-h-[400px]">
                    <div className="card-header flex justify-between items-center mb-4 pb-3 border-b border-slate-100">
                      <div>
                        <h3 className="text-base font-bold text-slate-800">Daily Appointment Stream</h3>
                        <p className="text-[11px] text-slate-500 mt-0.5">Chronological roster of medical consultations</p>
                      </div>
                      <button
                        onClick={() => openBookAppt()}
                        className="px-3 py-1.5 bg-sky-600 hover:bg-sky-700 text-white rounded-lg text-xs font-bold transition flex items-center gap-1 shadow-sm shadow-sky-600/10"
                      >
                        <Plus size={14} />
                        <span>Schedule Slot</span>
                      </button>
                    </div>

                    <div className="flex-1 space-y-2.5 max-h-[340px] overflow-y-auto pr-1">
                      {appointments.length === 0 ? (
                        <div className="h-full flex flex-col items-center justify-center text-center p-8">
                          <Clock className="text-slate-300 mb-2" size={32} />
                          <span className="text-xs font-semibold text-slate-400">No scheduled appointments found for today.</span>
                        </div>
                      ) : (
                        appointments
                          .filter(appt => appt.status !== 'Cancelled')
                          .sort((a, b) => `${a.date} ${a.time}`.localeCompare(`${b.date} ${b.time}`))
                          .map((appt) => {
                            // Find if this appointment is involved in a conflict
                            const hasConflict = appointments.some(other => (
                              other.id !== appt.id &&
                              other.status !== 'Cancelled' &&
                              other.doctorName.toLowerCase() === appt.doctorName.toLowerCase() &&
                              other.date === appt.date &&
                              (() => {
                                const parseMin = (t: string) => {
                                  const p = t.split(':');
                                  return parseInt(p[0], 10) * 60 + parseInt(p[1], 10);
                                };
                                const s1 = parseMin(appt.time);
                                const e1 = s1 + appt.duration;
                                const s2 = parseMin(other.time);
                                const e2 = s2 + other.duration;
                                return s1 < e2 && s2 < e1;
                              })()
                            ));

                            return (
                              <div
                                key={appt.id}
                                onClick={() => setViewingAppt(appt)}
                                className={`p-3.5 rounded-xl border transition-all cursor-pointer flex justify-between items-start ${
                                  hasConflict
                                    ? 'bg-rose-50/45 border-rose-200/75 hover:bg-rose-50/70 shadow-sm'
                                    : 'bg-white/40 border-white/60 hover:bg-white/60 hover:border-slate-300/40'
                                }`}
                              >
                                <div className="space-y-1">
                                  <div className="flex items-center gap-2">
                                    <span className="text-xs font-bold text-slate-800">{appt.patientName}</span>
                                    <span className="text-[9px] px-1.5 py-0.5 bg-slate-100/80 rounded text-slate-500 font-mono">
                                      {appt.patientId}
                                    </span>
                                    {hasConflict && (
                                      <span className="text-[9px] px-1.5 py-0.5 bg-rose-100 text-rose-800 rounded font-bold flex items-center gap-0.5">
                                        <AlertTriangle size={8} />
                                        Conflict Overlap
                                      </span>
                                    )}
                                  </div>
                                  
                                  <div className="flex items-center gap-3 text-[11px] text-slate-500 font-semibold">
                                    <span className="flex items-center gap-1 text-slate-700">
                                      <Stethoscope size={11} className="text-sky-600" />
                                      {appt.doctorName}
                                    </span>
                                    <span className="text-slate-300">•</span>
                                    <span>{appt.specialty}</span>
                                  </div>

                                  {appt.notes && (
                                    <p className="text-[10px] text-slate-500 line-clamp-1 italic mt-1">
                                      "{appt.notes}"
                                    </p>
                                  )}
                                </div>

                                <div className="text-right space-y-1 flex-shrink-0">
                                  <div className="text-xs font-bold text-slate-700 flex items-center gap-1 justify-end">
                                    <Clock size={11} className="text-indigo-500" />
                                    <span>{appt.time}</span>
                                  </div>
                                  <div className="text-[10px] text-slate-400 font-medium">
                                    {appt.duration} mins ({appt.date})
                                  </div>
                                  <div className="mt-1">
                                    <span className={`text-[9px] px-1.5 py-0.5 font-bold rounded-full uppercase ${
                                      appt.status === 'Scheduled' ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'
                                    }`}>
                                      {appt.status}
                                    </span>
                                  </div>
                                </div>
                              </div>
                            );
                          })
                      )}
                    </div>

                    <div className="integrity-footer mt-auto pt-3 border-t border-slate-100 text-[10px] font-mono text-slate-500 text-center">
                      Binary Data Vault: <span className="font-bold">APPOINTMENTS.DAT</span> | MD5: Verified Clean
                    </div>
                  </div>

                  {/* RIGHT PANEL: Bento Blocks */}
                  <div className="lg:col-span-5 space-y-6">
                    
                    {/* Active Patient Summary Section */}
                    <div className="glass-panel p-5 rounded-2xl flex flex-col justify-between">
                      <div className="flex justify-between items-center mb-3.5 pb-2 border-b border-slate-100">
                        <h3 className="text-sm font-bold text-slate-800">Featured Health Tracker</h3>
                        <span className="text-[9px] px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-full font-bold">
                          Sync Status: Active
                        </span>
                      </div>

                      {patients.length > 0 ? (
                        <div className="space-y-3">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-xl bg-sky-500/10 text-sky-600 flex items-center justify-center font-bold text-sm border border-sky-400/20">
                              {patients[0].name.charAt(0)}
                            </div>
                            <div>
                              <h4 className="text-sm font-bold text-slate-800">{patients[0].name}</h4>
                              <div className="text-[10px] font-mono text-slate-500">ID: {patients[0].id}</div>
                            </div>
                          </div>

                          <div className="space-y-2 pt-1">
                            <div className="flex justify-between text-xs font-semibold">
                              <span className="text-slate-500">Blood Type:</span>
                              <span className="text-slate-800 px-1.5 py-0.2 bg-sky-50 text-sky-700 rounded font-bold text-[10px]">
                                {patients[0].bloodType}
                              </span>
                            </div>
                            <div className="flex justify-between text-xs font-semibold">
                              <span className="text-slate-500">Admission Date:</span>
                              <span className="text-slate-800">{patients[0].dateRegistered}</span>
                            </div>
                            <div className="flex justify-between text-xs font-semibold">
                              <span className="text-slate-500">Known Allergies:</span>
                              <span className="text-rose-600 font-bold truncate max-w-[160px]">
                                {patients[0].allergies || 'None recorded'}
                              </span>
                            </div>
                          </div>

                          <button
                            onClick={() => {
                              setViewingPatient(patients[0]);
                              setActiveTab('patients');
                            }}
                            className="w-full mt-2 py-1.5 bg-white/65 hover:bg-white text-slate-700 border border-slate-200 text-[11px] font-bold rounded-lg transition"
                          >
                            Access Full Clinical History
                          </button>
                        </div>
                      ) : (
                        <div className="text-center py-6 text-xs text-slate-400">
                          No health summaries registered.
                        </div>
                      )}
                    </div>

                    {/* Workflow Efficiency Bar Chart */}
                    <div className="glass-panel p-5 rounded-2xl flex flex-col justify-between">
                      <div>
                        <h3 className="text-sm font-bold text-slate-800">Weekly Consultations Flow</h3>
                        <p className="text-[10px] text-slate-500 mt-0.5">Allocation rate per weekday</p>
                      </div>

                      <div className="flex items-end justify-between gap-3 h-28 mt-4">
                        {appointmentsPerDay.map((item) => (
                          <div key={item.day} className="flex-1 flex flex-col items-center gap-1.5">
                            {/* Bar container */}
                            <div className="w-full bg-slate-200/45 rounded-md h-20 relative overflow-hidden flex items-end">
                              <div
                                style={{ height: `${item.percentage}%` }}
                                className="w-full bg-sky-500/80 rounded-b-md rounded-t-sm transition-all duration-500 shadow-inner"
                              ></div>
                              <span className="absolute inset-0 flex items-center justify-center text-[9px] font-bold text-slate-700">
                                {item.count}
                              </span>
                            </div>
                            <span className="text-[10px] font-bold text-slate-500">
                              {item.day.slice(0, 3)}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                  </div>
                </div>

              </div>
            )}


            {/* --- VIEW: PATIENTS EHR --- */}
            {activeTab === 'patients' && (
              <div id="patients-viewport" className="space-y-6">
                
                {/* Advanced filters */}
                <div className="glass-panel p-4 rounded-xl flex flex-wrap gap-4 items-center justify-between">
                  <div className="flex flex-wrap gap-3 items-center">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-slate-600">
                      <Filter size={14} className="text-slate-400" />
                      <span>Filter Registers:</span>
                    </div>

                    {/* Gender select */}
                    <select
                      value={genderFilter}
                      onChange={(e) => setGenderFilter(e.target.value)}
                      className="glass-input text-xs font-semibold text-slate-700 px-3 py-1.5 rounded-lg border border-slate-200"
                    >
                      <option value="All">All Genders</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </select>

                    {/* Blood select */}
                    <select
                      value={bloodFilter}
                      onChange={(e) => setBloodFilter(e.target.value)}
                      className="glass-input text-xs font-semibold text-slate-700 px-3 py-1.5 rounded-lg border border-slate-200"
                    >
                      <option value="All">All Blood Types</option>
                      {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map(type => (
                        <option key={type} value={type}>{type}</option>
                      ))}
                    </select>
                  </div>

                  <button
                    onClick={openAddPatient}
                    className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-md shadow-sky-600/10"
                  >
                    <UserPlus size={14} />
                    <span>Create Record File</span>
                  </button>
                </div>

                {/* Patient Records Layout: Split Screen */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  
                  {/* Left Column: Records list */}
                  <div className="lg:col-span-7 glass-panel p-6 rounded-2xl flex flex-col min-h-[460px]">
                    <div className="flex justify-between items-center pb-3 border-b border-slate-100 mb-4">
                      <div>
                        <h3 className="text-sm font-bold text-slate-800">Patient Records System</h3>
                        <p className="text-[11px] text-slate-500 mt-0.5">Found {filteredPatients.length} medical file(s)</p>
                      </div>
                    </div>

                    <div className="space-y-3 overflow-y-auto max-h-[440px] pr-1 flex-1">
                      {filteredPatients.length === 0 ? (
                        <div className="text-center py-12 text-slate-400 text-xs font-semibold">
                          No patient records matched the active filters or search queries.
                        </div>
                      ) : (
                        filteredPatients.map(p => (
                          <div
                            key={p.id}
                            onClick={() => setViewingPatient(p)}
                            className={`p-4 rounded-xl border transition-all cursor-pointer flex justify-between items-center ${
                              viewingPatient?.id === p.id
                                ? 'bg-sky-500/10 border-sky-400/40 shadow-sm'
                                : 'bg-white/40 border-white/60 hover:bg-white/60 hover:border-slate-300/40'
                            }`}
                          >
                            <div className="space-y-1.5">
                              <div className="flex items-center gap-2">
                                <span className="text-sm font-bold text-slate-800">{p.name}</span>
                                <span className="text-[9px] px-1.5 py-0.5 bg-slate-100 text-slate-500 font-mono font-bold rounded">
                                  {p.id}
                                </span>
                              </div>

                              <div className="flex flex-wrap items-center gap-y-1 gap-x-4 text-[11px] text-slate-500 font-semibold">
                                <span className="flex items-center gap-1">
                                  <User size={11} className="text-slate-400" />
                                  DOB: {p.dob}
                                </span>
                                <span>•</span>
                                <span>Gender: {p.gender}</span>
                                <span>•</span>
                                <span className="text-sky-700 bg-sky-50 px-1 py-0.2 rounded text-[10px] font-bold">
                                  Type: {p.bloodType}
                                </span>
                              </div>

                              {p.allergies && (
                                <div className="text-[10px] text-rose-700 font-medium bg-rose-50/50 border border-rose-100/50 px-2 py-0.5 rounded max-w-max flex items-center gap-1">
                                  <AlertTriangle size={10} className="text-rose-500" />
                                  <span>Allergies: {p.allergies}</span>
                                </div>
                              )}
                            </div>

                            <div className="flex items-center gap-2">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  openEditPatient(p);
                                }}
                                className="p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-800 rounded-lg transition"
                                title="Edit Clinical File"
                              >
                                <Edit2 size={13} />
                              </button>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeletePatient(p.id);
                                }}
                                className="p-1.5 text-rose-500 hover:bg-rose-50 hover:text-rose-700 rounded-lg transition"
                                title="Wipe Record"
                              >
                                <Trash2 size={13} />
                              </button>
                              <ChevronRight className="text-slate-400" size={16} />
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>

                  {/* Right Column: Detailed Clinical Viewer */}
                  <div className="lg:col-span-5">
                    {viewingPatient ? (
                      <div className="glass-panel p-6 rounded-2xl flex flex-col space-y-5 min-h-[460px] animate-fade-in">
                        <div className="flex justify-between items-start pb-3 border-b border-slate-100">
                          <div>
                            <span className="text-[10px] font-mono font-bold text-slate-400 bg-slate-50 px-1.5 py-0.5 rounded">
                              {viewingPatient.id}
                            </span>
                            <h3 className="text-lg font-bold text-slate-800 mt-1">{viewingPatient.name}</h3>
                          </div>
                          <button
                            onClick={() => setViewingPatient(null)}
                            className="p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-lg transition"
                          >
                            <X size={16} />
                          </button>
                        </div>

                        {/* Visual details */}
                        <div className="space-y-4 text-xs">
                          
                          {/* Demographics row */}
                          <div className="grid grid-cols-2 gap-3 bg-white/40 p-3 rounded-xl border border-white/60">
                            <div>
                              <div className="text-slate-400 font-bold text-[9px] uppercase tracking-wider">Date of Birth</div>
                              <div className="font-bold text-slate-800 mt-0.5">{viewingPatient.dob}</div>
                            </div>
                            <div>
                              <div className="text-slate-400 font-bold text-[9px] uppercase tracking-wider">Gender Identity</div>
                              <div className="font-bold text-slate-800 mt-0.5">{viewingPatient.gender}</div>
                            </div>
                            <div className="mt-2">
                              <div className="text-slate-400 font-bold text-[9px] uppercase tracking-wider">Blood Type</div>
                              <div className="font-bold text-sky-700 text-sm mt-0.5">{viewingPatient.bloodType}</div>
                            </div>
                            <div className="mt-2">
                              <div className="text-slate-400 font-bold text-[9px] uppercase tracking-wider">Contact Number</div>
                              <div className="font-bold text-slate-800 mt-0.5">{viewingPatient.contact}</div>
                            </div>
                          </div>

                          {/* Clinical metadata */}
                          <div className="space-y-3">
                            <div>
                              <label className="text-slate-400 font-bold text-[9px] uppercase tracking-wider block mb-1">
                                Known Allergies
                              </label>
                              <div className={`p-2.5 rounded-xl border font-semibold ${
                                viewingPatient.allergies
                                  ? 'bg-rose-50/50 border-rose-100 text-rose-800'
                                  : 'bg-emerald-50/30 border-emerald-100/50 text-emerald-800'
                              }`}>
                                {viewingPatient.allergies || 'No known environmental or chemical hypersensitivities.'}
                              </div>
                            </div>

                            <div>
                              <label className="text-slate-400 font-bold text-[9px] uppercase tracking-wider block mb-1">
                                Medical History & Directives
                              </label>
                              <div className="p-3 bg-white/30 border border-white/60 rounded-xl font-medium text-slate-700 leading-relaxed min-h-[80px]">
                                {viewingPatient.medicalHistory || 'No previous diagnoses recorded in this clinical terminal.'}
                              </div>
                            </div>
                          </div>

                          {/* Appointments associated with this patient */}
                          <div>
                            <label className="text-slate-400 font-bold text-[9px] uppercase tracking-wider block mb-2">
                              Allotted Schedule Allocations
                            </label>
                            <div className="space-y-1.5 max-h-[140px] overflow-y-auto">
                              {appointments.filter(a => a.patientId === viewingPatient.id).length === 0 ? (
                                <div className="text-center py-4 bg-white/20 rounded-xl border border-dashed border-slate-200 text-slate-400 text-[10px] font-medium">
                                  No previous scheduled slots found for this record.
                                </div>
                              ) : (
                                appointments
                                  .filter(a => a.patientId === viewingPatient.id)
                                  .map(a => (
                                    <div key={a.id} className="p-2.5 bg-white/50 border border-white/80 rounded-xl flex justify-between items-center text-[11px]">
                                      <div>
                                        <div className="font-bold text-slate-800">{a.doctorName}</div>
                                        <div className="text-slate-500 font-semibold">{a.specialty}</div>
                                      </div>
                                      <div className="text-right">
                                        <div className="font-mono font-bold text-slate-700">{a.date} @ {a.time}</div>
                                        <span className={`text-[8px] px-1.5 font-extrabold rounded-full ${
                                          a.status === 'Scheduled' ? 'bg-amber-100 text-amber-800' :
                                          a.status === 'Completed' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-500'
                                        }`}>
                                          {a.status}
                                        </span>
                                      </div>
                                    </div>
                                  ))
                              )}
                            </div>
                          </div>

                          {/* Quick Actions */}
                          <div className="pt-2 flex gap-2">
                            <button
                              onClick={() => openBookAppt(viewingPatient.id)}
                              className="flex-1 py-2 bg-sky-600 text-white rounded-lg font-bold text-center hover:bg-sky-700 transition"
                            >
                              Allocate Appointment Slot
                            </button>
                            <button
                              onClick={() => openEditPatient(viewingPatient)}
                              className="px-3.5 py-2 bg-white/60 hover:bg-white text-slate-700 border border-slate-200 rounded-lg font-bold transition"
                            >
                              Modify File
                            </button>
                          </div>

                        </div>
                      </div>
                    ) : (
                      <div className="glass-panel p-6 rounded-2xl flex flex-col justify-center items-center text-center space-y-2 min-h-[460px] text-slate-400">
                        <Users size={40} className="text-slate-300" />
                        <span className="text-xs font-bold text-slate-500">No Patient Selected</span>
                        <p className="text-[11px] max-w-xs leading-relaxed text-slate-400">
                          Select a patient from the list registry to inspect their full diagnostic parameters, allergies, and scheduled history parameters.
                        </p>
                      </div>
                    )}
                  </div>

                </div>

              </div>
            )}


            {/* --- VIEW: DOCTOR SCHEDULE --- */}
            {activeTab === 'schedule' && (
              <div id="schedule-viewport" className="space-y-6">
                
                {/* Filters Row */}
                <div className="glass-panel p-4 rounded-xl flex flex-wrap gap-4 items-center justify-between">
                  <div className="flex flex-wrap gap-3 items-center">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-slate-600">
                      <Filter size={14} className="text-slate-400" />
                      <span>Specialist:</span>
                    </div>

                    <select
                      value={doctorFilter}
                      onChange={(e) => setDoctorFilter(e.target.value)}
                      className="glass-input text-xs font-semibold text-slate-700 px-3 py-1.5 rounded-lg border border-slate-200"
                    >
                      <option value="All">All Doctors</option>
                      {doctors.map(d => (
                        <option key={d.name} value={d.name}>{d.name}</option>
                      ))}
                    </select>
                  </div>

                  <button
                    onClick={() => openBookAppt()}
                    className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-md shadow-sky-600/10"
                  >
                    <Plus size={14} />
                    <span>Schedule Appointment</span>
                  </button>
                </div>

                {/* Scheduling Layout */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  
                  {/* Left list: appointments */}
                  <div className="lg:col-span-7 glass-panel p-6 rounded-2xl min-h-[460px] flex flex-col">
                    <div className="pb-3 border-b border-slate-100 mb-4">
                      <h3 className="text-sm font-bold text-slate-800">Master Roster</h3>
                      <p className="text-[11px] text-slate-500 mt-0.5">Found {filteredAppointments.length} consultation block(s)</p>
                    </div>

                    <div className="space-y-3 overflow-y-auto max-h-[440px] pr-1 flex-1">
                      {filteredAppointments.length === 0 ? (
                        <div className="text-center py-12 text-slate-400 text-xs font-semibold">
                          No appointments found for the selected specialist or search term.
                        </div>
                      ) : (
                        filteredAppointments
                          .sort((a, b) => `${a.date} ${a.time}`.localeCompare(`${b.date} ${b.time}`))
                          .map(appt => {
                            // Local conflict check for conflict highlights
                            const isConflicted = appointments.some(other => (
                              other.id !== appt.id &&
                              other.status !== 'Cancelled' &&
                              other.doctorName.toLowerCase() === appt.doctorName.toLowerCase() &&
                              other.date === appt.date &&
                              (() => {
                                const parseMin = (t: string) => {
                                  const p = t.split(':');
                                  return parseInt(p[0], 10) * 60 + parseInt(p[1], 10);
                                };
                                const s1 = parseMin(appt.time);
                                const e1 = s1 + appt.duration;
                                const s2 = parseMin(other.time);
                                const e2 = s2 + other.duration;
                                return s1 < e2 && s2 < e1;
                              })()
                            ));

                            return (
                              <div
                                key={appt.id}
                                onClick={() => setViewingAppt(appt)}
                                className={`p-4 rounded-xl border transition-all cursor-pointer flex justify-between items-start ${
                                  isConflicted
                                    ? 'bg-rose-50/50 border-rose-300'
                                    : appt.status === 'Cancelled'
                                      ? 'bg-slate-100/50 border-slate-200 text-slate-400 opacity-60'
                                      : 'bg-white/40 border-white/60 hover:bg-white/60 hover:border-slate-300/40'
                                }`}
                              >
                                <div className="space-y-1.5">
                                  <div className="flex items-center gap-2">
                                    <span className="text-sm font-bold text-slate-800">{appt.patientName}</span>
                                    <span className="text-[9px] px-1.5 py-0.5 bg-slate-100 text-slate-500 font-mono font-bold rounded">
                                      {appt.patientId}
                                    </span>
                                    {isConflicted && (
                                      <span className="text-[9px] px-1.5 py-0.5 bg-rose-100 text-rose-800 rounded font-bold flex items-center gap-0.5">
                                        <AlertTriangle size={8} />
                                        Overlap Conflict
                                      </span>
                                    )}
                                  </div>

                                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-slate-500 font-semibold">
                                    <span className="flex items-center gap-1 text-slate-800">
                                      <Stethoscope size={11} className="text-sky-600" />
                                      {appt.doctorName}
                                    </span>
                                    <span>•</span>
                                    <span>{appt.specialty}</span>
                                  </div>

                                  {appt.notes && (
                                    <p className="text-[10px] text-slate-500 line-clamp-1 italic mt-1 bg-white/20 p-1.5 rounded border border-white/40">
                                      "{appt.notes}"
                                    </p>
                                  )}
                                </div>

                                <div className="text-right space-y-1 flex-shrink-0 ml-4">
                                  <div className="text-xs font-mono font-bold text-slate-800 flex items-center gap-1 justify-end">
                                    <Clock size={11} className="text-indigo-500" />
                                    <span>{appt.time}</span>
                                  </div>
                                  <div className="text-[10px] text-slate-500 font-medium">
                                    {appt.date} ({appt.duration}m)
                                  </div>
                                  <div>
                                    <span className={`text-[9px] px-1.5 py-0.2 font-bold rounded uppercase ${
                                      appt.status === 'Scheduled' ? 'bg-amber-100 text-amber-800' :
                                      appt.status === 'Completed' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'
                                    }`}>
                                      {appt.status}
                                    </span>
                                  </div>
                                </div>
                              </div>
                            );
                          })
                      )}
                    </div>
                  </div>

                  {/* Right Column: Appointment Details / Conflict Advisor */}
                  <div className="lg:col-span-5">
                    {viewingAppt ? (
                      <div className="glass-panel p-6 rounded-2xl flex flex-col space-y-5 min-h-[460px] animate-fade-in">
                        <div className="flex justify-between items-start pb-3 border-b border-slate-100">
                          <div>
                            <span className="text-[10px] font-mono font-bold text-slate-400 bg-slate-50 px-1.5 py-0.5 rounded">
                              {viewingAppt.id}
                            </span>
                            <h3 className="text-base font-bold text-slate-800 mt-1">Allocation Details</h3>
                          </div>
                          <button
                            onClick={() => setViewingAppt(null)}
                            className="p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-lg transition"
                          >
                            <X size={16} />
                          </button>
                        </div>

                        {/* Visual parameters */}
                        <div className="space-y-4 text-xs">
                          
                          {/* Main block */}
                          <div className="bg-white/40 p-3 rounded-xl border border-white/60 space-y-2">
                            <div className="flex justify-between">
                              <span className="text-slate-400 font-bold text-[9px] uppercase tracking-wider">Patient</span>
                              <span className="font-bold text-slate-800">{viewingAppt.patientName} ({viewingAppt.patientId})</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-400 font-bold text-[9px] uppercase tracking-wider">Physician</span>
                              <span className="font-bold text-sky-700">{viewingAppt.doctorName}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-400 font-bold text-[9px] uppercase tracking-wider">Department</span>
                              <span className="font-bold text-slate-800">{viewingAppt.specialty}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-400 font-bold text-[9px] uppercase tracking-wider">Date & Time</span>
                              <span className="font-mono font-bold text-slate-800">{viewingAppt.date} @ {viewingAppt.time}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-400 font-bold text-[9px] uppercase tracking-wider">Duration</span>
                              <span className="font-bold text-slate-800">{viewingAppt.duration} Minutes</span>
                            </div>
                          </div>

                          {/* Conflict advice */}
                          {appointments.some(other => (
                            other.id !== viewingAppt.id &&
                            other.status !== 'Cancelled' &&
                            other.doctorName.toLowerCase() === viewingAppt.doctorName.toLowerCase() &&
                            other.date === viewingAppt.date &&
                            (() => {
                              const parseMin = (t: string) => {
                                const p = t.split(':');
                                return parseInt(p[0], 10) * 60 + parseInt(p[1], 10);
                              };
                              const s1 = parseMin(viewingAppt.time);
                              const e1 = s1 + viewingAppt.duration;
                              const s2 = parseMin(other.time);
                              const e2 = s2 + other.duration;
                              return s1 < e2 && s2 < e1;
                            })()
                          )) && (
                            <div className="p-3 bg-rose-50 border border-rose-100 text-rose-800 rounded-xl space-y-1.5">
                              <div className="flex items-center gap-1.5 font-bold text-[11px] text-rose-900">
                                <AlertTriangle size={14} className="text-rose-600 animate-pulse" />
                                Overlap Confirmed
                              </div>
                              <p className="text-[10px] leading-relaxed">
                                This physician is assigned to another active consultation block during these exact parameters. Please reschedule or modify the time constraints.
                              </p>
                            </div>
                          )}

                          {/* Notes Block */}
                          <div>
                            <label className="text-slate-400 font-bold text-[9px] uppercase tracking-wider block mb-1">
                              Clinical Directives / Notes
                            </label>
                            <div className="p-3 bg-white/30 border border-white/60 rounded-xl font-medium text-slate-700 leading-relaxed min-h-[70px]">
                              {viewingAppt.notes || 'No special medical directives attached to this slot.'}
                            </div>
                          </div>

                          {/* Quick status cycle toggle */}
                          <div>
                            <span className="text-slate-400 font-bold text-[9px] uppercase tracking-wider block mb-2">
                              Change Appointment Status
                            </span>
                            <div className="grid grid-cols-3 gap-2">
                              {['Scheduled', 'Completed', 'Cancelled'].map(status => (
                                <button
                                  key={status}
                                  onClick={async () => {
                                    try {
                                      const response = await fetch(`/api/appointments/${viewingAppt.id}`, {
                                        method: 'PUT',
                                        headers: { 'Content-Type': 'application/json' },
                                        body: JSON.stringify({ ...viewingAppt, status })
                                      });
                                      if (response.ok) {
                                        const updated = await response.json();
                                        setAppointments(prev => prev.map(a => a.id === updated.id ? updated : a));
                                        setViewingAppt(updated);
                                        setSuccessMsg(`Status updated: ${status}`);
                                      } else {
                                        const err = await response.json();
                                        setError(err.message || 'Overlap detected when changing status back.');
                                      }
                                    } catch (err) {
                                      setError('Failed to update.');
                                    }
                                  }}
                                  className={`py-1.5 text-center text-[10px] font-bold rounded-lg border transition ${
                                    viewingAppt.status === status
                                      ? 'bg-sky-600 text-white border-sky-600 shadow-sm'
                                      : 'bg-white/50 text-slate-600 border-slate-200 hover:bg-slate-50'
                                  }`}
                                >
                                  {status}
                                </button>
                              ))}
                            </div>
                          </div>

                          {/* Footer action */}
                          <div className="pt-2 flex gap-2">
                            <button
                              onClick={() => openEditAppt(viewingAppt)}
                              className="flex-1 py-2 bg-sky-600 text-white rounded-lg font-bold hover:bg-sky-700 transition"
                            >
                              Reschedule Slot
                            </button>
                            <button
                              onClick={() => handleDeleteAppointment(viewingAppt.id)}
                              className="px-3.5 py-2 bg-rose-50 text-rose-700 border border-rose-100 rounded-lg font-bold hover:bg-rose-100 transition"
                            >
                              Wipe Slot
                            </button>
                          </div>

                        </div>
                      </div>
                    ) : (
                      <div className="glass-panel p-6 rounded-2xl flex flex-col justify-center items-center text-center space-y-2 min-h-[460px] text-slate-400">
                        <Calendar size={40} className="text-slate-300" />
                        <span className="text-xs font-bold text-slate-500">No Allocation Selected</span>
                        <p className="text-[11px] max-w-xs leading-relaxed text-slate-400">
                          Select an appointment from the roster to inspect physician allocation details, update status states, or verify overlaps.
                        </p>
                      </div>
                    )}
                  </div>

                </div>

              </div>
            )}


            {/* --- VIEW: DATABASE DIAGNOSTICS --- */}
            {activeTab === 'diagnostics' && (
              <div id="diagnostics-viewport" className="space-y-6">
                
                {/* Tech Intro */}
                <div className="glass-panel p-5 rounded-2xl space-y-3">
                  <div className="flex items-center gap-2 text-sky-800">
                    <Database size={20} className="text-sky-600" />
                    <h3 className="font-bold text-sm">VitaFlow Encrypted Binary Storage Vault</h3>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Unlike standard web prototypes that use simulated local states, VitaFlow preserves data integrity by writing structured clinical objects to binary <span className="font-mono font-bold">.dat</span> files directly in the backend storage systems.
                  </p>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Each record frame begins with a unique <strong className="text-slate-700">4-byte Magic Header</strong>, followed by a <strong className="text-slate-700">4-byte frame length parameter (UInt32 Big-Endian)</strong>, and a secure <strong className="text-slate-700">XOR-obfuscated (cipher key 0xAA) UTF-8 string payload</strong>.
                  </p>
                </div>

                {/* File metrics */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  {/* Patients File diagnostics */}
                  <div className="glass-panel p-6 rounded-2xl flex flex-col justify-between space-y-4">
                    <div className="flex justify-between items-start border-b border-slate-100 pb-3">
                      <div>
                        <span className="text-[10px] font-mono font-bold text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">
                          VAULT_PART_01
                        </span>
                        <h4 className="text-base font-bold text-slate-800 mt-1">patients.dat</h4>
                      </div>
                      <span className="text-[10px] bg-emerald-50 text-emerald-800 font-bold border border-emerald-100/50 px-2.5 py-0.5 rounded-full uppercase">
                        {diagnostics?.patientsFile.exists ? 'Online' : 'Offline'}
                      </span>
                    </div>

                    <div className="space-y-2 text-xs">
                      <div className="flex justify-between font-semibold">
                        <span className="text-slate-500">Relative Path:</span>
                        <span className="font-mono text-slate-700">data/patients.dat</span>
                      </div>
                      <div className="flex justify-between font-semibold">
                        <span className="text-slate-500">File Capacity Size:</span>
                        <span className="font-mono text-slate-700 font-bold">{diagnostics?.patientsFile.size || 0} Bytes</span>
                      </div>
                      <div className="flex justify-between font-semibold">
                        <span className="text-slate-500">Record Frames Count:</span>
                        <span className="font-mono text-slate-700 font-bold">{diagnostics?.patientsFile.recordCount || 0}</span>
                      </div>
                    </div>

                    <div>
                      <span className="text-[9px] uppercase font-bold tracking-wider text-slate-400 block mb-1.5">
                        Raw Frame Hex Dump (Header & XOR Cipher)
                      </span>
                      <div className="p-3 bg-slate-900 text-slate-300 font-mono text-[10px] rounded-xl overflow-x-auto select-all leading-relaxed tracking-wider shadow-inner">
                        {diagnostics?.patientsFile.hexSnippet ? (
                          <>
                            <span className="text-sky-400 font-bold" title="Patient Magic Byte 0x50 0x41 0x54 0x01">50 41 54 01</span>{' '}
                            {diagnostics.patientsFile.hexSnippet.split(' ').slice(4).join(' ')}
                          </>
                        ) : (
                          'No active payload frames loaded.'
                        )}
                      </div>
                      <span className="text-[9px] text-slate-400 mt-1.5 block italic">
                        Highlighted blue bytes indicate the Patient Magic aligned frame header.
                      </span>
                    </div>
                  </div>

                  {/* Appointments File diagnostics */}
                  <div className="glass-panel p-6 rounded-2xl flex flex-col justify-between space-y-4">
                    <div className="flex justify-between items-start border-b border-slate-100 pb-3">
                      <div>
                        <span className="text-[10px] font-mono font-bold text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">
                          VAULT_PART_02
                        </span>
                        <h4 className="text-base font-bold text-slate-800 mt-1">appointments.dat</h4>
                      </div>
                      <span className="text-[10px] bg-emerald-50 text-emerald-800 font-bold border border-emerald-100/50 px-2.5 py-0.5 rounded-full uppercase">
                        {diagnostics?.appointmentsFile.exists ? 'Online' : 'Offline'}
                      </span>
                    </div>

                    <div className="space-y-2 text-xs">
                      <div className="flex justify-between font-semibold">
                        <span className="text-slate-500">Relative Path:</span>
                        <span className="font-mono text-slate-700">data/appointments.dat</span>
                      </div>
                      <div className="flex justify-between font-semibold">
                        <span className="text-slate-500">File Capacity Size:</span>
                        <span className="font-mono text-slate-700 font-bold">{diagnostics?.appointmentsFile.size || 0} Bytes</span>
                      </div>
                      <div className="flex justify-between font-semibold">
                        <span className="text-slate-500">Record Frames Count:</span>
                        <span className="font-mono text-slate-700 font-bold">{diagnostics?.appointmentsFile.recordCount || 0}</span>
                      </div>
                    </div>

                    <div>
                      <span className="text-[9px] uppercase font-bold tracking-wider text-slate-400 block mb-1.5">
                        Raw Frame Hex Dump (Header & XOR Cipher)
                      </span>
                      <div className="p-3 bg-slate-900 text-slate-300 font-mono text-[10px] rounded-xl overflow-x-auto select-all leading-relaxed tracking-wider shadow-inner">
                        {diagnostics?.appointmentsFile.hexSnippet ? (
                          <>
                            <span className="text-indigo-400 font-bold" title="Appointment Magic Byte 0x41 0x50 0x54 0x01">41 50 54 01</span>{' '}
                            {diagnostics.appointmentsFile.hexSnippet.split(' ').slice(4).join(' ')}
                          </>
                        ) : (
                          'No active payload frames loaded.'
                        )}
                      </div>
                      <span className="text-[9px] text-slate-400 mt-1.5 block italic">
                        Highlighted indigo bytes indicate the Appointment Magic aligned frame header.
                      </span>
                    </div>
                  </div>

                </div>

                {/* Operations tools */}
                <div className="glass-panel p-5 rounded-2xl flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-bold text-slate-800">Integrity Check & Re-Seed</h4>
                    <p className="text-[11px] text-slate-500 mt-0.5">Purge system files and re-seed the sandbox defaults.</p>
                  </div>
                  <button
                    onClick={async () => {
                      if (confirm('Warning: This will delete patients.dat and appointments.dat on the server and restore the clinical template defaults. This cannot be undone. Restructure?')) {
                        try {
                          // We can purge on server by deleting the database files
                          // But wait! Deleting them and running fetchInitialData will make server re-seed them!
                          // Let's call DELETE on all patients first to cascade delete
                          setLoading(true);
                          await Promise.all(
                            patients.map(p => fetch(`/api/patients/${p.id}`, { method: 'DELETE' }))
                          );
                          // Re-fetch to let server re-seed
                          await fetchInitialData();
                          setSuccessMsg('Clinical storage vault cleanly re-seeded.');
                        } catch (e) {
                          setError('Failed to seed.');
                        } finally {
                          setLoading(false);
                        }
                      }
                    }}
                    className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm"
                  >
                    <RefreshCw size={12} />
                    <span>Reset & Seed Database</span>
                  </button>
                </div>

              </div>
            )}


            {/* --- VIEW: STAFF REGISTRY --- */}
            {activeTab === 'staff' && (
              <div id="staff-viewport" className="space-y-6 animate-fade-in">
                
                <div className="glass-panel p-5 rounded-2xl">
                  <h3 className="text-base font-bold text-slate-800">VFLOW Certified Physicians</h3>
                  <p className="text-xs text-slate-500 mt-1">
                    On-duty registry and clinical specialties. The on-duty status is computed dynamically according to the patient coordinator calendar days.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {doctors.map(doc => {
                    const currentDay = getSimulatedDayName();
                    const isOnDuty = doc.availability.days.includes(currentDay);
                    const apptCount = appointments.filter(a => a.doctorName === doc.name && a.status === 'Scheduled').length;

                    return (
                      <div key={doc.name} className="glass-panel p-5 rounded-2xl flex flex-col justify-between space-y-4 hover:translate-y-[-2px] transition-transform">
                        <div className="flex justify-between items-start">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-xl bg-sky-500/10 text-sky-600 flex items-center justify-center font-bold text-sm border border-sky-400/20">
                              {doc.name.split(' ').pop()?.slice(0, 2).toUpperCase() || 'MD'}
                            </div>
                            <div>
                              <h4 className="text-sm font-bold text-slate-800">{doc.name}</h4>
                              <span className="text-[10px] font-semibold text-slate-500 block mt-0.5">{doc.specialty}</span>
                            </div>
                          </div>

                          <span className={`text-[9px] px-2 py-0.5 font-bold rounded-full uppercase ${
                            isOnDuty
                              ? 'bg-emerald-100 text-emerald-800 animate-pulse'
                              : 'bg-slate-100 text-slate-500'
                          }`}>
                            {isOnDuty ? 'On Duty' : 'Off Duty'}
                          </span>
                        </div>

                        <div className="space-y-2 text-xs border-t border-slate-100 pt-3">
                          <div className="flex justify-between font-semibold">
                            <span className="text-slate-400 flex items-center gap-1">
                              <MapPin size={11} />
                              Consultation Room:
                            </span>
                            <span className="text-slate-700">{doc.room}</span>
                          </div>
                          
                          <div className="flex justify-between font-semibold">
                            <span className="text-slate-400 flex items-center gap-1">
                              <Clock size={11} />
                              Hours shift:
                            </span>
                            <span className="text-slate-700">{doc.availability.hours}</span>
                          </div>

                          <div className="flex justify-between font-semibold">
                            <span className="text-slate-400 flex items-center gap-1">
                              <Calendar size={11} />
                              Days shift:
                            </span>
                            <span className="text-slate-700 text-right max-w-[150px] truncate" title={doc.availability.days.join(', ')}>
                              {doc.availability.days.join(', ')}
                            </span>
                          </div>
                        </div>

                        <div className="bg-white/45 p-2.5 rounded-xl border border-white/60 flex items-center justify-between">
                          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Scheduled Slots Today</span>
                          <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                            apptCount > 0 ? 'bg-sky-100 text-sky-800' : 'bg-slate-100 text-slate-500'
                          }`}>
                            {apptCount} appt(s)
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>

              </div>
            )}

          </div>
        </main>

      </div>

      {/* ========================================================= */}
      {/* --- CLINICAL EDITING MODALS (FROSTED GLASS OVERLAYS) --- */}
      {/* ========================================================= */}

      {/* PATIENT MODAL */}
      {isPatientModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-md animate-fade-in">
          <div className="glass-panel w-full max-w-lg p-6 rounded-2xl shadow-2xl relative overflow-hidden flex flex-col">
            <div className="flex justify-between items-center pb-3 border-b border-slate-200/50 mb-4">
              <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
                <UserPlus size={18} className="text-sky-600" />
                <span>{patientFormMode === 'add' ? 'Create Electronic Health Record' : 'Modify Electronic Health Record'}</span>
              </h3>
              <button
                onClick={() => setIsPatientModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-lg transition"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleSavePatient} className="space-y-4 text-xs">
              
              {/* Name & DOB */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-500 font-bold uppercase text-[9px] block">Patient Name *</label>
                  <input
                    type="text"
                    required
                    value={patientForm.name}
                    onChange={(e) => setPatientForm(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="e.g. Sarah Connor"
                    className="w-full glass-input px-3 py-2 rounded-lg text-xs"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-500 font-bold uppercase text-[9px] block">Date of Birth *</label>
                  <input
                    type="date"
                    required
                    value={patientForm.dob}
                    onChange={(e) => setPatientForm(prev => ({ ...prev, dob: e.target.value }))}
                    className="w-full glass-input px-3 py-2 rounded-lg text-xs"
                  />
                </div>
              </div>

              {/* Gender & Blood Group */}
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-500 font-bold uppercase text-[9px] block">Gender</label>
                  <select
                    value={patientForm.gender}
                    onChange={(e) => setPatientForm(prev => ({ ...prev, gender: e.target.value as Patient['gender'] }))}
                    className="w-full glass-input px-3 py-2 rounded-lg text-xs"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-slate-500 font-bold uppercase text-[9px] block">Blood Type</label>
                  <select
                    value={patientForm.bloodType}
                    onChange={(e) => setPatientForm(prev => ({ ...prev, bloodType: e.target.value as Patient['bloodType'] }))}
                    className="w-full glass-input px-3 py-2 rounded-lg text-xs"
                  >
                    {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map(t => (
                      <option key={t} value={t}>{t}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Contact */}
              <div className="space-y-1">
                <label className="text-slate-500 font-bold uppercase text-[9px] block">Contact Number *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 555-0199"
                  value={patientForm.contact}
                  onChange={(e) => setPatientForm(prev => ({ ...prev, contact: e.target.value }))}
                  className="w-full glass-input px-3 py-2 rounded-lg text-xs"
                />
              </div>

              {/* Allergies */}
              <div className="space-y-1">
                <label className="text-slate-500 font-bold uppercase text-[9px] block">Known Allergies</label>
                <input
                  type="text"
                  placeholder="e.g. Penicillin, Peanuts (leave blank if none)"
                  value={patientForm.allergies}
                  onChange={(e) => setPatientForm(prev => ({ ...prev, allergies: e.target.value }))}
                  className="w-full glass-input px-3 py-2 rounded-lg text-xs border-rose-200/50"
                />
              </div>

              {/* Medical History */}
              <div className="space-y-1">
                <label className="text-slate-500 font-bold uppercase text-[9px] block">Medical History Directives</label>
                <textarea
                  rows={3}
                  placeholder="Chronic conditions, past procedures, active prescriptions..."
                  value={patientForm.medicalHistory}
                  onChange={(e) => setPatientForm(prev => ({ ...prev, medicalHistory: e.target.value }))}
                  className="w-full glass-input px-3 py-2 rounded-lg text-xs"
                />
              </div>

              {/* Footer Buttons */}
              <div className="pt-3 border-t border-slate-200/50 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsPatientModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl font-bold transition shadow-sm"
                >
                  Verify & Preserve
                </button>
              </div>

            </form>
          </div>
        </div>
      )}


      {/* APPOINTMENT MODAL */}
      {isApptModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-md animate-fade-in">
          <div className="glass-panel w-full max-w-lg p-6 rounded-2xl shadow-2xl relative overflow-hidden flex flex-col">
            <div className="flex justify-between items-center pb-3 border-b border-slate-200/50 mb-4">
              <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
                <Calendar size={18} className="text-sky-600" />
                <span>{apptFormMode === 'add' ? 'Allocate Appointment Slot' : 'Reschedule Allocation Slot'}</span>
              </h3>
              <button
                onClick={() => setIsApptModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-lg transition"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleSaveAppointment} className="space-y-4 text-xs">
              
              {/* Dynamic Live Conflict Advisor inside booking window */}
              {clientConflict && (
                <div id="booking-conflict-warning" className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-2 text-amber-900 animate-pulse">
                  <AlertTriangle className="text-amber-600 flex-shrink-0 mt-0.5" size={16} />
                  <div>
                    <h5 className="font-bold text-[11px]">Conflict Slot Interception</h5>
                    <p className="text-[10px] leading-relaxed mt-0.5">
                      {apptForm.doctorName} already has an active scheduled appointment on this day around {clientConflict.time} for {clientConflict.patientName}. Proceeding may result in dual bookings.
                    </p>
                  </div>
                </div>
              )}

              {/* Patient Selector */}
              <div className="space-y-1">
                <label className="text-slate-500 font-bold uppercase text-[9px] block">Assign Patient Record *</label>
                <select
                  required
                  value={apptForm.patientId}
                  onChange={(e) => setApptForm(prev => ({ ...prev, patientId: e.target.value }))}
                  className="w-full glass-input px-3 py-2 rounded-lg text-xs font-semibold"
                >
                  <option value="" disabled>-- Select Patient Record --</option>
                  {patients.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.name} (ID: {p.id}, Blood Type: {p.bloodType})
                    </option>
                  ))}
                </select>
              </div>

              {/* Doctor Selector */}
              <div className="space-y-1">
                <label className="text-slate-500 font-bold uppercase text-[9px] block">Assign Clinical Specialist *</label>
                <select
                  required
                  value={apptForm.doctorName}
                  onChange={(e) => setApptForm(prev => ({ ...prev, doctorName: e.target.value }))}
                  className="w-full glass-input px-3 py-2 rounded-lg text-xs font-semibold"
                >
                  <option value="" disabled>-- Select Doctor --</option>
                  {doctors.map(d => (
                    <option key={d.name} value={d.name}>
                      {d.name} ({d.specialty} • {d.room})
                    </option>
                  ))}
                </select>
                {apptForm.doctorName && (
                  <span className="text-[9px] text-slate-500 mt-1 block italic">
                    Physician shifts availability: {doctors.find(d => d.name === apptForm.doctorName)?.availability.days.join(', ')} ({doctors.find(d => d.name === apptForm.doctorName)?.availability.hours})
                  </span>
                )}
              </div>

              {/* Date & Time */}
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-500 font-bold uppercase text-[9px] block">Consultation Date *</label>
                  <input
                    type="date"
                    required
                    value={apptForm.date}
                    onChange={(e) => setApptForm(prev => ({ ...prev, date: e.target.value }))}
                    className="w-full glass-input px-3 py-2 rounded-lg text-xs"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-500 font-bold uppercase text-[9px] block">Start Time (HH:MM) *</label>
                  <input
                    type="time"
                    required
                    value={apptForm.time}
                    onChange={(e) => setApptForm(prev => ({ ...prev, time: e.target.value }))}
                    className="w-full glass-input px-3 py-2 rounded-lg text-xs"
                  />
                </div>
              </div>

              {/* Duration & Status */}
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-500 font-bold uppercase text-[9px] block">Duration (Minutes)</label>
                  <select
                    value={apptForm.duration}
                    onChange={(e) => setApptForm(prev => ({ ...prev, duration: parseInt(e.target.value, 10) }))}
                    className="w-full glass-input px-3 py-2 rounded-lg text-xs font-semibold"
                  >
                    <option value={15}>15 Minutes</option>
                    <option value={30}>30 Minutes (Standard)</option>
                    <option value={45}>45 Minutes (Extended)</option>
                    <option value={60}>60 Minutes (Comprehensive)</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-slate-500 font-bold uppercase text-[9px] block">Consultation Status</label>
                  <select
                    value={apptForm.status}
                    onChange={(e) => setApptForm(prev => ({ ...prev, status: e.target.value as Appointment['status'] }))}
                    className="w-full glass-input px-3 py-2 rounded-lg text-xs"
                  >
                    <option value="Scheduled">Scheduled</option>
                    <option value="Completed">Completed</option>
                    <option value="Cancelled">Cancelled</option>
                  </select>
                </div>
              </div>

              {/* Notes */}
              <div className="space-y-1">
                <label className="text-slate-500 font-bold uppercase text-[9px] block">Clinical Reason / Notes</label>
                <textarea
                  rows={2}
                  placeholder="Reason for visit, triage concerns, or diagnostic notes..."
                  value={apptForm.notes}
                  onChange={(e) => setApptForm(prev => ({ ...prev, notes: e.target.value }))}
                  className="w-full glass-input px-3 py-2 rounded-lg text-xs"
                />
              </div>

              {/* Footer Buttons */}
              <div className="pt-3 border-t border-slate-200/50 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsApptModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!!clientConflict && apptForm.status !== 'Cancelled'}
                  className={`px-5 py-2 text-white rounded-xl font-bold transition shadow-sm ${
                    clientConflict && apptForm.status !== 'Cancelled'
                      ? 'bg-amber-600 hover:bg-amber-700 cursor-pointer'
                      : 'bg-sky-600 hover:bg-sky-700'
                  }`}
                >
                  {clientConflict && apptForm.status !== 'Cancelled' ? 'Force Allocation' : 'Book Appointment'}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}
