/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Patient {
  id: string; // PAT-YYYY-XXXX
  name: string;
  dob: string; // YYYY-MM-DD
  gender: 'Male' | 'Female' | 'Other';
  bloodType: 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';
  contact: string;
  allergies: string;
  medicalHistory: string;
  dateRegistered: string; // ISO string or YYYY-MM-DD
}

export interface Appointment {
  id: string; // APT-YYYY-XXXX
  patientId: string;
  patientName: string;
  doctorName: string;
  specialty: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
  duration: number; // in minutes (e.g., 30, 45, 60)
  status: 'Scheduled' | 'Completed' | 'Cancelled';
  notes: string;
}

export interface Doctor {
  name: string;
  specialty: string;
  room: string;
  availability: {
    days: string[]; // e.g. ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
    hours: string; // e.g. "09:00 - 17:00"
  };
}

export interface DbDiagnostics {
  patientsFile: {
    path: string;
    exists: boolean;
    size: number;
    recordCount: number;
    hexSnippet: string; // Stylized hex string of first N bytes
  };
  appointmentsFile: {
    path: string;
    exists: boolean;
    size: number;
    recordCount: number;
    hexSnippet: string; // Stylized hex string of first N bytes
  };
}
