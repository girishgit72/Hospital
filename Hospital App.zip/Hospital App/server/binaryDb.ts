/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import fs from 'fs/promises';
import { existsSync } from 'fs';
import path from 'path';
import { Patient, Appointment } from '../src/types';

const DATA_DIR = path.join(process.cwd(), 'data');
const PATIENTS_FILE = path.join(DATA_DIR, 'patients.dat');
const APPOINTMENTS_FILE = path.join(DATA_DIR, 'appointments.dat');

// Binary magic headers (4 bytes)
const PATIENT_MAGIC = Buffer.from([0x50, 0x41, 0x54, 0x01]); // "PAT\x01"
const APPOINTMENT_MAGIC = Buffer.from([0x41, 0x50, 0x54, 0x01]); // "APT\x01"

// Obfuscation key for security (XOR mask)
const XOR_KEY = 0xAA;

/**
 * Obfuscates/De-obfuscates buffer payload with XOR cipher
 */
function xorBuffer(buf: Buffer): Buffer {
  const result = Buffer.alloc(buf.length);
  for (let i = 0; i < buf.length; i++) {
    result[i] = buf[i] ^ XOR_KEY;
  }
  return result;
}

/**
 * Serializes list of records into a single binary buffer
 */
function serialize<T>(records: T[], magic: Buffer): Buffer {
  const chunks: Buffer[] = [];

  for (const record of records) {
    // 1. Convert record to JSON and encode as UTF-8 Buffer
    const jsonStr = JSON.stringify(record);
    let payload = Buffer.from(jsonStr, 'utf-8');

    // 2. Encrypt/Obfuscate payload
    payload = xorBuffer(payload);

    // 3. Create frame: Magic (4B) + Payload Length (4B, Uint32BE) + Payload
    const frameHeader = Buffer.alloc(8);
    magic.copy(frameHeader, 0, 0, 4);
    frameHeader.writeUInt32BE(payload.length, 4);

    chunks.push(frameHeader, payload);
  }

  return Buffer.concat(chunks);
}

/**
 * Deserializes binary buffer back into list of records
 */
function deserialize<T>(buffer: Buffer, expectedMagic: Buffer): T[] {
  const records: T[] = [];
  let offset = 0;

  while (offset < buffer.length) {
    // Check if we have enough bytes for header (8 bytes)
    if (offset + 8 > buffer.length) {
      break;
    }

    // Read and verify magic bytes
    const fileMagic = buffer.subarray(offset, offset + 4);
    if (!fileMagic.equals(expectedMagic)) {
      // If magic mismatch, slide forward 1 byte to find alignment, or break
      offset++;
      continue;
    }

    // Read payload length (Big Endian)
    const payloadLen = buffer.readUInt32BE(offset + 4);
    offset += 8;

    // Check if we have enough bytes for payload
    if (offset + payloadLen > buffer.length) {
      break;
    }

    // Extract payload buffer
    let payload = buffer.subarray(offset, offset + payloadLen);
    offset += payloadLen;

    // Decrypt/De-obfuscate payload
    payload = xorBuffer(payload);

    try {
      const jsonStr = payload.toString('utf-8');
      const record = JSON.parse(jsonStr) as T;
      records.push(record);
    } catch (err) {
      console.error('Failed to parse binary record:', err);
    }
  }

  return records;
}

/**
 * Ensures data directory exists
 */
async function ensureDataDir() {
  if (!existsSync(DATA_DIR)) {
    await fs.mkdir(DATA_DIR, { recursive: true });
  }
}

/**
 * Loads all patients from patients.dat
 */
export async function loadPatients(): Promise<Patient[]> {
  await ensureDataDir();
  if (!existsSync(PATIENTS_FILE)) {
    // Seed default patients if file doesn't exist
    const defaultPatients: Patient[] = [
      {
        id: 'PAT-2026-0001',
        name: 'Sarah Connor',
        dob: '1984-11-13',
        gender: 'Female',
        bloodType: 'A+',
        contact: '555-0199',
        allergies: 'Penicillin, Sulfa drugs',
        medicalHistory: 'Chronic stress, past trauma, bullet wound history. Fit cardiovascular system.',
        dateRegistered: '2026-01-10'
      },
      {
        id: 'PAT-2026-0002',
        name: 'John Doe',
        dob: '1990-05-24',
        gender: 'Male',
        bloodType: 'O-',
        contact: '555-8941',
        allergies: 'Peanuts',
        medicalHistory: 'Hypertension controlled with lisinopril. Routine vision checks.',
        dateRegistered: '2026-02-14'
      },
      {
        id: 'PAT-2026-0003',
        name: 'Amara Smith',
        dob: '1978-08-05',
        gender: 'Female',
        bloodType: 'AB+',
        contact: '555-3210',
        allergies: 'None',
        medicalHistory: 'Type 2 Diabetes mellitus managed via diet and metformin.',
        dateRegistered: '2026-03-22'
      },
      {
        id: 'PAT-2026-0004',
        name: 'Bruce Banner',
        dob: '1969-12-18',
        gender: 'Male',
        bloodType: 'B+',
        contact: '555-4733',
        allergies: 'Gamma radiation exposure (hypersensitivity)',
        medicalHistory: 'Severe anger management issues. High adrenaline peaks. Heart rate monitoring required.',
        dateRegistered: '2026-04-01'
      }
    ];
    await savePatients(defaultPatients);
    return defaultPatients;
  }

  try {
    const data = await fs.readFile(PATIENTS_FILE);
    return deserialize<Patient>(data, PATIENT_MAGIC);
  } catch (err) {
    console.error('Error reading patients file:', err);
    return [];
  }
}

/**
 * Saves all patients to patients.dat
 */
export async function savePatients(patients: Patient[]): Promise<void> {
  await ensureDataDir();
  try {
    const data = serialize(patients, PATIENT_MAGIC);
    await fs.writeFile(PATIENTS_FILE, data);
  } catch (err) {
    console.error('Error writing patients file:', err);
  }
}

/**
 * Loads all appointments from appointments.dat
 */
export async function loadAppointments(): Promise<Appointment[]> {
  await ensureDataDir();
  if (!existsSync(APPOINTMENTS_FILE)) {
    // Seed default appointments if file doesn't exist
    const defaultAppointments: Appointment[] = [
      {
        id: 'APT-2026-0001',
        patientId: 'PAT-2026-0001',
        patientName: 'Sarah Connor',
        doctorName: 'Dr. Gregory House',
        specialty: 'Diagnostic Medicine',
        date: '2026-07-08',
        time: '09:00',
        duration: 45,
        status: 'Scheduled',
        notes: 'Evaluation of complex, episodic somatic complaints. Rule out heavy metal poisoning.'
      },
      {
        id: 'APT-2026-0002',
        patientId: 'PAT-2026-0002',
        patientName: 'John Doe',
        doctorName: 'Dr. Meredith Grey',
        specialty: 'General Surgery',
        date: '2026-07-08',
        time: '11:00',
        duration: 30,
        status: 'Scheduled',
        notes: 'Post-op follow up check on abdominal wound healing. Remove remaining sutures.'
      },
      {
        id: 'APT-2026-0003',
        patientId: 'PAT-2026-0004',
        patientName: 'Bruce Banner',
        doctorName: 'Dr. Stephen Strange',
        specialty: 'Neurology',
        date: '2026-07-09',
        time: '14:00',
        duration: 60,
        status: 'Scheduled',
        notes: 'Neurological examination to assess brain waves during stress test triggers.'
      }
    ];
    await saveAppointments(defaultAppointments);
    return defaultAppointments;
  }

  try {
    const data = await fs.readFile(APPOINTMENTS_FILE);
    return deserialize<Appointment>(data, APPOINTMENT_MAGIC);
  } catch (err) {
    console.error('Error reading appointments file:', err);
    return [];
  }
}

/**
 * Saves all appointments to appointments.dat
 */
export async function saveAppointments(appointments: Appointment[]): Promise<void> {
  await ensureDataDir();
  try {
    const data = serialize(appointments, APPOINTMENT_MAGIC);
    await fs.writeFile(APPOINTMENTS_FILE, data);
  } catch (err) {
    console.error('Error writing appointments file:', err);
  }
}

/**
 * Fetches details about files for diagnostics
 */
export async function getDbDiagnostics() {
  await ensureDataDir();

  const getFileStats = async (filePath: string, expectedMagic: Buffer) => {
    const exists = existsSync(filePath);
    let size = 0;
    let recordCount = 0;
    let hexSnippet = '';

    if (exists) {
      const stats = await fs.stat(filePath);
      size = stats.size;

      const buffer = await fs.readFile(filePath);
      const records = deserialize<any>(buffer, expectedMagic);
      recordCount = records.length;

      // Create hex snippet of first 48 bytes
      const bytesToDump = Math.min(buffer.length, 48);
      const hexParts: string[] = [];
      for (let i = 0; i < bytesToDump; i++) {
        hexParts.push(buffer[i].toString(16).padStart(2, '0').toUpperCase());
      }
      hexSnippet = hexParts.join(' ') + (buffer.length > bytesToDump ? ' ...' : '');
    }

    return {
      path: path.basename(filePath),
      exists,
      size,
      recordCount,
      hexSnippet
    };
  };

  return {
    patientsFile: await getFileStats(PATIENTS_FILE, PATIENT_MAGIC),
    appointmentsFile: await getFileStats(APPOINTMENTS_FILE, APPOINTMENT_MAGIC)
  };
}
